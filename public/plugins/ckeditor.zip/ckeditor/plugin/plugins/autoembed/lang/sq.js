/*
 Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */
CKEDITOR.plugins.setLang( 'autoembed', 'sq', {
	embeddingInProgress: 'Duke tentuar të shtojë URL-në e hedhur...',
	embeddingFailed: 'Kjo URL nuk mund të shtohet në mënyrë automatike.'
} );
