/*
 Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */
CKEDITOR.plugins.setLang( 'autoembed', 'ko', {
	embeddingInProgress: '붙여넣은 URL 첨부 시도 중...',
	embeddingFailed: '이 URL은 자동으로 첨부할 수 없습니다.'
} );
